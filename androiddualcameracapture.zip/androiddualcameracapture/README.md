Demo code for synchronous dual camera access under Android.
Depends on OpenCV 2.4.9 http://opencv.org/downloads.html

Tested under a HTC One M8. 